# StormWake V18 PC — build Windows EXE automatically

1. Create a new GitHub repository.
2. Upload the contents of this folder (keep `tauri/` and the HTML together).
3. Open **Actions** and run **Build Windows Installer**.
4. When it finishes, open the workflow run and download the artifact **StormWake-V18-PC-Windows-Installer**.
5. The ZIP contains the Windows `.exe` installer.

The build runs on a Windows GitHub runner, so your phone does not need Rust, Node, or a Windows PC.
